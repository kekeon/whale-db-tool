--name:create-system_user

CREATE TABLE system_user (
  id INTEGER PRIMARY KEY,
  account TEXT NULL,
  password TEXT NULL,
  public_key TEXT NULL,
  private_key TEXT  NULL,
  other_info TEXT NULL
)

--name:insert-system_user-root_admin
INSERT INTO system_user (account,password)
VALUES (?, ?);

--name:create-database_user
CREATE TABLE database_user (
  id INTEGER PRIMARY KEY,
  user_id TEXT NOT NULL,
  connection_another_name TEXT NULL,
  connection_uuid TEXT NULL,
  connection_host TEXT NULL,
  connection_port TEXT NULL,
  connection_account TEXT NULL,
  connection_password TEXT NULL,
  connection_type TEXT NULL,
  create_time NUMERIC NULL,
  update_time NUMERIC NULL,
  other_info TEXT NULL
)
